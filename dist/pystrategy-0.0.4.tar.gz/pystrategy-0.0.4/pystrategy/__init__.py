import pystrategy


__all__=['EWStrategy', 'resta_function']
