from config_libaries import *
from main import py_strategy

